package dev.minihax

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import dev.sora.relay.MinecraftRelay
import dev.sora.relay.MinecraftRelayListener
import dev.sora.relay.cheat.command.CommandManager
import dev.sora.relay.cheat.module.ModuleManager
import dev.sora.relay.game.GameSession
import dev.sora.relay.session.MinecraftRelaySession
import dev.sora.relay.session.listener.RelayListenerAutoCodec
import dev.sora.relay.session.listener.RelayListenerEncryptedSession
import dev.sora.relay.session.listener.RelayListenerNetworkSettings
import dev.sora.relay.session.listener.xbox.RelayListenerXboxLogin
import dev.sora.relay.session.listener.xbox.XboxDeviceInfo
import dev.sora.relay.session.listener.xbox.cache.XboxIdentityTokenCacheFileSystem
import java.io.File
import java.net.InetSocketAddress
import kotlin.concurrent.thread

class RelayService : Service() {

	private var relay: MinecraftRelay? = null

	override fun onBind(intent: Intent?): IBinder? = null

	override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
		if (intent?.action == ACTION_STOP) {
			stopRelay()
			stopSelf()
			return START_NOT_STICKY
		}
		val host = intent?.getStringExtra("host") ?: return START_NOT_STICKY
		val port = intent.getIntExtra("port", 19132)

		startForeground(1, buildNotification())

		// sesión de juego + módulos (incluye LB-FLY)
		val gameSession = GameSession()
		val manager = ModuleManager(gameSession).also { it.init() }
		CommandManager(gameSession).init(manager)
		moduleManager = manager

		thread(name = "relay-start") {
			try {
				startRelay(host, port, gameSession)
				running = true
				lastMessage = "Relay activo en 127.0.0.1:$LOCAL_PORT -> $host:$port"
			} catch (e: Throwable) {
				running = false
				lastMessage = "Error: ${e.javaClass.simpleName}: ${e.message}"
			}
		}
		return START_NOT_STICKY
	}

	private fun startRelay(host: String, port: Int, gameSession: GameSession) {
		val dst = InetSocketAddress(host, port)
		val tokenFile = File(filesDir, "ms_token")

		val sessionEncryptor = if (tokenFile.exists()) {
			val deviceInfo = XboxDeviceInfo.DEVICE_NINTENDO
			RelayListenerXboxLogin({
				val (accessToken, refreshToken) = deviceInfo.refreshToken(tokenFile.readText())
				tokenFile.writeText(refreshToken)
				accessToken
			}, deviceInfo).also {
				it.tokenCache = XboxIdentityTokenCacheFileSystem(File(filesDir, "token_cache.json"), "account")
				it.forceFetchChain()
			}
		} else {
			RelayListenerEncryptedSession()
		}

		val r = MinecraftRelay(object : MinecraftRelayListener {
			override fun onSessionCreation(session: MinecraftRelaySession): InetSocketAddress {
				session.listeners.add(RelayListenerNetworkSettings(session))
				session.listeners.add(RelayListenerAutoCodec(session))
				gameSession.netSession = session
				session.listeners.add(gameSession)
				sessionEncryptor.session = session
				session.listeners.add(sessionEncryptor)
				return dst
			}
		})
		r.bind(InetSocketAddress("0.0.0.0", LOCAL_PORT))
		relay = r
	}

	private fun stopRelay() {
		try { relay?.stop() } catch (_: Throwable) {}
		relay = null
		running = false
		moduleManager = null
		lastMessage = "Relay detenido"
	}

	override fun onDestroy() {
		stopRelay()
		super.onDestroy()
	}

	private fun buildNotification(): Notification {
		val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
		nm.createNotificationChannel(NotificationChannel("relay", "Relay", NotificationManager.IMPORTANCE_LOW))
		return Notification.Builder(this, "relay")
			.setContentTitle("MiniHax")
			.setContentText("Relay en 127.0.0.1:$LOCAL_PORT")
			.setSmallIcon(android.R.drawable.ic_dialog_info)
			.build()
	}

	companion object {
		const val ACTION_STOP = "dev.minihax.STOP"
		const val LOCAL_PORT = 19136

		@Volatile var running = false
		@Volatile var moduleManager: ModuleManager? = null
		@Volatile var lastMessage = "Detenido"
	}
}
