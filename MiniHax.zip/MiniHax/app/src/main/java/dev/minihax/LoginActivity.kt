package dev.minihax

import android.annotation.SuppressLint
import android.app.Activity
import android.net.Uri
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.File

/** Login de Microsoft con WebView. Guarda el código de autorización; el relay lo canjea al conectar. */
class LoginActivity : Activity() {

	@SuppressLint("SetJavaScriptEnabled")
	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		CookieManager.getInstance().removeAllCookies(null)

		val web = WebView(this)
		web.settings.javaScriptEnabled = true
		web.webViewClient = object : WebViewClient() {
			override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
				val url = request.url.toString()
				if (url.startsWith(REDIRECT)) {
					val code = Uri.parse(url).getQueryParameter("code")
					if (code != null) {
						File(filesDir, "ms_token").writeText(code)
						File(filesDir, "token_cache.json").delete()
						Toast.makeText(this@LoginActivity, "Login guardado", Toast.LENGTH_LONG).show()
					} else {
						Toast.makeText(this@LoginActivity, "No se recibió código", Toast.LENGTH_LONG).show()
					}
					finish()
					return true
				}
				return false
			}
		}
		setContentView(web)
		web.loadUrl(
			"https://login.live.com/oauth20_authorize.srf?client_id=00000000441cc96b" +
				"&response_type=code&scope=service%3A%3Auser.auth.xboxlive.com%3A%3AMBI_SSL" +
				"&redirect_uri=https%3A%2F%2Flogin.live.com%2Foauth20_desktop.srf&display=touch"
		)
	}

	companion object {
		const val REDIRECT = "https://login.live.com/oauth20_desktop.srf"
	}
}
