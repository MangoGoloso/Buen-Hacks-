package dev.minihax

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.View
import android.widget.*
import dev.sora.relay.cheat.module.CheatModule
import dev.sora.relay.cheat.value.Value
import java.io.File

class MainActivity : Activity() {

	private lateinit var hostInput: EditText
	private lateinit var portInput: EditText
	private lateinit var status: TextView
	private lateinit var modulesBox: LinearLayout
	private val handler = Handler(Looper.getMainLooper())

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)

		val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
		root.addView(TextView(this).apply { text = "MiniHax"; textSize = 26f })

		hostInput = EditText(this).apply { hint = "IP / dominio del servidor"; setText("mco.lbsg.net"); setSingleLine() }
		portInput = EditText(this).apply { hint = "Puerto"; setText("19132"); inputType = InputType.TYPE_CLASS_NUMBER }
		root.addView(hostInput); root.addView(portInput)

		root.addView(Button(this).apply {
			text = "Login Microsoft"
			setOnClickListener { startActivity(Intent(this@MainActivity, LoginActivity::class.java)) }
		})
		root.addView(Button(this).apply {
			text = "Iniciar relay"
			setOnClickListener {
				val i = Intent(this@MainActivity, RelayService::class.java)
					.putExtra("host", hostInput.text.toString().trim())
					.putExtra("port", portInput.text.toString().toIntOrNull() ?: 19132)
				startForegroundService(i)
				handler.postDelayed({ refresh() }, 800)
			}
		})
		root.addView(Button(this).apply {
			text = "Detener relay"
			setOnClickListener {
				startService(Intent(this@MainActivity, RelayService::class.java).setAction(RelayService.ACTION_STOP))
				handler.postDelayed({ refresh() }, 500)
			}
		})
		root.addView(Button(this).apply { text = "Actualizar estado y módulos"; setOnClickListener { refresh() } })

		status = TextView(this).apply { setPadding(0, 20, 0, 20) }
		root.addView(status)
		root.addView(TextView(this).apply {
			text = "En Minecraft agrega un servidor: 127.0.0.1  puerto ${RelayService.LOCAL_PORT}"
		})
		modulesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
		root.addView(modulesBox)

		setContentView(ScrollView(this).apply { addView(root) })
	}

	override fun onResume() {
		super.onResume()
		refresh()
	}

	private fun refresh() {
		val logged = File(filesDir, "ms_token").exists()
		status.text = "${RelayService.lastMessage}\nLogin Microsoft: ${if (logged) "sí" else "no (modo offline)"}"
		modulesBox.removeAllViews()
		val manager = RelayService.moduleManager ?: return
		manager.modules.sortedBy { it.name }.forEach { m ->
			val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
			row.addView(Switch(this).apply {
				text = m.name
				isChecked = m.state
				layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
				setOnCheckedChangeListener { _, checked -> if (m.state != checked) m.state = checked }
			})
			if (m.values.isNotEmpty()) {
				row.addView(Button(this).apply { text = "Ajustes"; setOnClickListener { showValues(m) } })
			}
			modulesBox.addView(row)
		}
	}

	@Suppress("UNCHECKED_CAST")
	private fun showValues(m: CheatModule) {
		val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0) }
		val appliers = mutableListOf<() -> Unit>()
		m.values.filter { it.visible }.forEach { v ->
			when (val cur = v.value) {
				is Boolean -> {
					val sw = Switch(this).apply { text = v.name; isChecked = cur }
					box.addView(sw)
					appliers += { (v as Value<Boolean>).value = sw.isChecked }
				}
				is Float -> {
					box.addView(TextView(this).apply { text = v.name })
					val et = EditText(this).apply {
						setText(cur.toString())
						inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
					}
					box.addView(et)
					appliers += { et.text.toString().toFloatOrNull()?.let { (v as Value<Float>).value = it } }
				}
				is Int -> {
					box.addView(TextView(this).apply { text = v.name })
					val et = EditText(this).apply { setText(cur.toString()); inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED }
					box.addView(et)
					appliers += { et.text.toString().toIntOrNull()?.let { (v as Value<Int>).value = it } }
				}
				else -> {}
			}
		}
		AlertDialog.Builder(this)
			.setTitle(m.name)
			.setView(ScrollView(this).apply { addView(box) })
			.setPositiveButton("Guardar") { _, _ -> appliers.forEach { it() } }
			.setNegativeButton("Cerrar", null)
			.show()
	}
}
