# MiniHax

App Android mínima: relay local de ProtoHax 2.2.1 (con LB-FLY) + menú para activar módulos.

## Compilar (GitHub Actions, sin PC)
1. Crea un repositorio en GitHub y sube TODO el contenido de esta carpeta.
2. Pestaña Actions -> "Build APK" -> Run workflow.
3. Cuando termine, descarga el artefacto `MiniHax-apk` (dentro está el .apk).

## Compilar en PC
JDK 17 + Android SDK, luego: ./gradlew assembleDebug
APK en app/build/outputs/apk/debug/

## Usar
1. Abre MiniHax -> "Login Microsoft" e inicia sesión (necesario para servidores con Xbox como Lifeboat).
2. Pon IP y puerto del servidor -> "Iniciar relay".
3. En Minecraft agrega un servidor 127.0.0.1 puerto 19136 y entra.
4. Vuelve a MiniHax -> "Actualizar estado y módulos" -> activa LB-FLY y ajusta con "Ajustes".

Limite: soporta Minecraft Bedrock hasta 1.20.10 (protocolo 594).
