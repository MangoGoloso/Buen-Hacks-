package dev.sora.relay.cheat.module.impl.movement

import dev.sora.relay.cheat.module.CheatCategory
import dev.sora.relay.cheat.module.CheatModule
import dev.sora.relay.game.event.EventTick
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.packet.SetEntityMotionPacket
import kotlin.math.cos
import kotlin.math.sin

/**
 * LB-FLY
 * - Horizontal: solo te mueves cuando presionas direccion (HorizontalSpeed, max 8).
 * - Vertical: saltar = subir, agacharse = bajar (VerticalSpeed, max 8).
 * - Sin tocar nada te quedas en el aire con Glide (0 = no bajas, negativo = bajas despacio).
 * - AntiKick: cada X ticks hace un "bob" (baja un poco y recupera en el tick siguiente)
 *   para que no parezca que flotas quieto.
 */
class ModuleLBFly : CheatModule("LB-FLY", CheatCategory.MOVEMENT) {

	private var horizontalSpeedValue by floatValue("HorizontalSpeed", 0.8f, 0.1f..8f)
	private var verticalSpeedValue by floatValue("VerticalSpeed", 0.8f, 0.1f..8f)
	private var glideValue by floatValue("Glide", 0f, -0.5f..0f)
	private var antiKickValue by boolValue("AntiKick", true)
	private var antiKickIntervalValue by intValue("AntiKickInterval", 20, 5..60)
	private var antiKickDropValue by floatValue("AntiKickDrop", 0.08f, 0.02f..0.4f)

	private var recoverBob = 0f

	override fun onEnable() {
		recoverBob = 0f
	}

	override fun onDisable() {
		recoverBob = 0f
	}

	private val onTick = handle<EventTick> {
		val player = session.player

		// Vertical
		var motionY = glideValue.coerceAtMost(0f)
		if (player.inputData.contains(PlayerAuthInputData.JUMP_DOWN)) {
			motionY = verticalSpeedValue
		} else if (player.isSneaking) {
			motionY = -verticalSpeedValue
		} else if (antiKickValue) {
			// AntiKick solo cuando estas quieto en vertical
			if (recoverBob != 0f) {
				motionY = recoverBob
				recoverBob = 0f
			} else if (player.tickExists % antiKickIntervalValue == 0L) {
				motionY = -antiKickDropValue
				recoverBob = antiKickDropValue
			}
		}

		// Horizontal (solo si hay input de movimiento)
		val angle = player.moveDirectionAngle
		val motionX = if (angle != null) -sin(angle) * horizontalSpeedValue else 0f
		val motionZ = if (angle != null) cos(angle) * horizontalSpeedValue else 0f

		session.netSession.inboundPacket(SetEntityMotionPacket().apply {
			runtimeEntityId = player.runtimeEntityId
			motion = Vector3f.from(motionX, motionY, motionZ)
		})
	}
}
